import os
from flask import Flask, request, render_template, send_from_directory, redirect, url_for, jsonify
import cv2
from werkzeug.utils import secure_filename
from pymongo import MongoClient

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = './static/uploads'
app.config['PROCESSED_FOLDER'] = './static/processed'

# Ensure folders exist

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROCESSED_FOLDER'], exist_ok=True)

# Load the Haar cascade
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

client = MongoClient("mongodb://localhost:27017")  # Replace with your MongoDB URI
db = client.demo  # Access your database
collection = db.user


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle the uploaded file
        uploaded_file = request.files['image']
        user_id = request.form.get('user')

        if uploaded_file and user_id:
            # Create a directory for the user if it doesn't exist
            user_folder = os.path.join(app.config['UPLOAD_FOLDER'], user_id)
            collection.insert_one({
                "user_id": user_id,

            })
            os.makedirs(user_folder, exist_ok=True)

            # Save the uploaded file in the user's folder
            filename = secure_filename(uploaded_file.filename)
            filepath = os.path.join(user_folder, filename)
            print(filepath)
            uploaded_file.save(filepath)

            # Detect faces
            img = cv2.imread(filepath)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            res = []
            # Draw rectangles around faces
            for (x, y, w, h) in faces:
                res.append(gray[y:y + h, x:x + w])
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

            processed_path = os.path.join(app.config['PROCESSED_FOLDER'], filename)
            cv2.imwrite(processed_path, res[0])
            return jsonify('success')
            # return render_template('register.html', image_url=url_for('static', filename=f'processed/{filename}'))

    # return render_template('register.html')
    return jsonify('unable to process')


if __name__ == '__main__':
    app.run(debug=True)
