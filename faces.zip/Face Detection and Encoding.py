import cv2
import os
import numpy as np

# Directory to save registered faces
FACES_DIR = "faces"
os.makedirs(FACES_DIR, exist_ok=True)

# Initialize face detector
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

def capture_face(user_id):
    """Capture face and save to FACES_DIR."""
    cap = cv2.VideoCapture(0)
    print("Press 'q' to capture the face.")

    while True:
        ret, frame = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(50, 50))

        for (x, y, w, h) in faces:
            # Draw a rectangle around detected faces
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        cv2.imshow('Register Face', frame)

        # Press 'q' to save the face
        if cv2.waitKey(1) & 0xFF == ord('q'):
            for (x, y, w, h) in faces:
                face = gray[y:y+h, x:x+w]
                face_path = os.path.join(FACES_DIR, f"{user_id}.jpg")
                cv2.imwrite(face_path, face)
                print(f"Face captured and saved as {face_path}")
                break
            break

    cap.release()
    cv2.destroyAllWindows()

def load_face(user_id):
    """Load face encoding for a user."""
    face_path = os.path.join(FACES_DIR, f"{user_id}.jpg")
    if os.path.exists(face_path):
        return cv2.imread(face_path, cv2.IMREAD_GRAYSCALE)
    return None
